<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndicatorMoneySaveController extends Controller
{
    //
}
