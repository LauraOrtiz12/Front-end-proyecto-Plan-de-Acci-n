<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EstateIndicatorSaveController extends Controller
{
    //
}
