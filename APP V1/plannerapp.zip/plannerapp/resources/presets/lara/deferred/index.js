export default {
    root: {}
};
