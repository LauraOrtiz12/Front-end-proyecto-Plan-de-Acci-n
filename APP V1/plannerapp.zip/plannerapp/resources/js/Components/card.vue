<template>
    <div class="bg-white overflow-hidden shadow-md rounded-md w-fit">
        <slot />
    </div>
</template>
