<script setup>
const logo = '/assets/images/favicon.png';
</script>
<template>
    <img :src="logo" alt="SENA">
</template>
