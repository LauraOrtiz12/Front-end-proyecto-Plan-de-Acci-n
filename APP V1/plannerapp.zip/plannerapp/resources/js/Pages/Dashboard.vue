<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/card.vue';
import ApplicationLogo from '@/Components/ApplicationLogo.vue';

const pageTitle = "Dashboard";
</script>
<template>
    <AppLayout :title="pageTitle">
        <template #header>
            <h2 class="font-semibold text-xl text-secondary-default my-auto">{{ pageTitle }}</h2>
        </template>
        <Card>
            <div class="p-6 lg:p-8 bg-white border-b border-gray-200">
                <ApplicationLogo class="block h-12 w-auto" />

                <h1 class="mt-8 text-3xl font-bold text-gray-900 text-center">
                    Plan de Acción SENA // 2024
                </h1>
                <p class="mt-6 text-gray-700 leading-relaxed text-justify">
                    De acuerdo con la Constitución Política de Colombia, lo dispuesto en los artículos 26 y 29 de
                    la Ley 152 de 1994, y teniendo en cuenta que la entidad atiende las orientaciones dadas por
                    el Modelo Integrado de Planeación y Gestión (MIPG), el Plan de Acción 2024 establece las
                    acciones institucionales del SENA para la vigencia 2024, las cuales se encuentran articuladas
                    con las bases del Plan Nacional de Desarrollo, la ley 2294 de 2023 que establece el Plan
                    Nacional de Desarrollo (PND) 2022 – 2026, “Colombia Potencia Mundial de la Vida”, Planes
                    institucionales definidos en el Decreto 612 de 2018, y los documentos CONPES en los que
                    tiene compromisos la entidad. Dando cuenta de las principales orientaciones para lograr la
                    articulación entre la estrategia y operación del SENA como Entidad líder de formación para el
                    trabajo. Especialmente en la vigencia 2023 se enfocan las acciones y lineamientos para
                    cumplir las iniciativas del gobierno nacional.
                </p>
                <div class="mt-6 text-center">
                    <a href="https://www.sena.edu.co/es-co/sena/planeacion/PLAN_DE_ACCION_2024_CDN.pdf" target="_blank"
                        class="inline-block px-6 py-3 bg-blue-600 text-white font-medium text-sm leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out">
                        Descargar Documento
                    </a>
                </div>
            </div>

            <div class="bg-gray-200 bg-opacity-25 grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 p-6 lg:p-8">
                <div>
                    <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            class="w-6 h-6 stroke-gray-400">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                        </svg>
                        <h2 class="ms-3 text-xl font-semibold text-gray-900">
                            <a href="/manual/MANUAL_PLAN_DE_ACCION.pdf">Manual de Usuario de Centro Dependencia</a>
                        </h2>
                    </div>

                    <p class="mt-4 text-gray-500 text-sm leading-relaxed">
                        El Manual de Usuario del Módulo de Seguimiento de la Aplicación del Plan de Acción SENA es
                        un
                        recurso integral y detallado diseñado para asistir a los usuarios en el monitoreo y gestión
                        efectiva
                        de las acciones estratégicas definidas en el Plan de Acción. Este manual está estructurado
                        para
                        facilitar la comprensión y utilización de todas las funcionalidades del módulo,
                        proporcionando una
                        guía paso a paso para cada proceso relevante.
                    </p>

                    <p class="mt-4 text-sm">
                        <a href="/manual/MANUAL_PLAN_DE_ACCION.pdf"
                            class="inline-flex items-center font-semibold text-indigo-700">
                            Descargar Manual

                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                class="ms-1 w-5 h-5 fill-indigo-500">
                                <path fill-rule="evenodd"
                                    d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    </p>
                </div>
                <div>
                    <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            class="w-6 h-6 stroke-gray-400">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                        </svg>
                        <h2 class="ms-3 text-xl font-semibold text-gray-900">
                            <a href="/manual/MANUAL_PLAN_DE_ACCION.pdf">Manual de Usuario Control</a>
                        </h2>
                    </div>
                    <p class="mt-4 text-gray-500 text-sm leading-relaxed">
                        El Manual de Usuario del Módulo de Seguimiento de la Aplicación del Plan de Acción SENA es
                        un
                        recurso integral y detallado diseñado para asistir a los usuarios en el monitoreo y gestión
                        efectiva
                        de las acciones estratégicas definidas en el Plan de Acción. Este manual está estructurado
                        para
                        facilitar la comprensión y utilización de todas las funcionalidades del módulo,
                        proporcionando una
                        guía paso a paso para cada proceso relevante.
                    </p>
                    <p class="mt-4 text-sm">
                        <a href="/manual/MANUAL_PLAN_DE_ACCION.pdf"
                            class="inline-flex items-center font-semibold text-indigo-700">
                            Descargar Manual

                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                class="ms-1 w-5 h-5 fill-indigo-500">
                                <path fill-rule="evenodd"
                                    d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    </p>
                </div>
            </div>


            <div class="bg-gray-200 bg-opacity-25 grid grid-cols-1 md:grid-cols-1 gap-6 lg:gap-8 p-6 lg:p-8">
                <div>
                    <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                             class="w-6 h-6 stroke-gray-400">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                        </svg>
                        <h2 class="ms-3 text-xl font-semibold text-gray-900">
                            <a href="/hv/HOJAS_DE_VIDA_INDICADORES.zip">Hoja de Vida de Indicadores</a>
                        </h2>
                    </div>

                    <p class="mt-4 text-sm">
                        <a href="/hv/HOJAS_DE_VIDA_INDICADORES.zip"
                           class="inline-flex items-center font-semibold text-indigo-700">
                            Clic para descargar Hojas de Vida de Indicadores
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                 class="ms-1 w-5 h-5 fill-indigo-500">
                                <path fill-rule="evenodd"
                                      d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z"
                                      clip-rule="evenodd" />
                            </svg>
                        </a>
                    </p>
                </div>

            </div>

            <footer class="bg-gray-100 p-4 mt-6 text-center text-sm text-gray-500">
                Desarrollado por la Fábrica de Software del Centro de Diseño e Innovación Tecnológica Industrial en
                Dosquebradas.
                <span class="text-xs font-italic">
                    v1.0.0
                </span>
            </footer>
        </Card>
    </AppLayout>
</template>
