<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Data</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #f4f4f4;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Custom styles */
        .bgcolor-lightgrey {
            background-color: lightgrey;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .valign-middle {
            vertical-align: middle;
        }

        .bold {
            font-weight: bold;
        }
    </style>
</head>
<body>
<div style="font-family: arial; width: 100%">
    <h1>Seguimiento de la Vigencia</h1>
    <table>
        <thead>
        <tr>
            <th>Código Regional</th>
            <th>Dependencia Control / Regional</th>
            <th>Código Dependencia</th>
            <th>Dependencia</th>
            <th>Vigencia</th>
            <th>Código Indicador</th>
            <th>Nombre Indicador</th>
            <th>Mes</th>
            <th>Meta</th>
            <th>Ejecución</th>
            <th>Porcentaje Ejecución</th>
            <th>Porcentaje Esperado</th>
            <th>Justificación de Indicadores</th>
            <th>Justificación de Presupuesto</th>
            <th>Observación Control</th>
            <th>Nombre Perspectiva</th>
            <th>Objetivo Estrategico</th>
            <th>Iniciativa Estratégica</th>
            <th>Fecha Inicial</th>
            <th>Fecha Final</th>
            <th>Recurso Físico</th>
            <th>Recurso Técnico</th>
            <th>Recurso Humano</th>
            <th>Responsable de Indicador</th>
            <th>Cargo Responsable Indicador</th>
            <th>Asesor</th>
            <th>Responsable de Indicador</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $followupComplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-format="0" class="text-right"><?php echo e($item['cod_reg']); ?></td>
                <td data-format="0" class="text-right"><?php echo e($item['cod_control']); ?></td>
                <td data-format="0" class="text-right"><?php echo e($item['cod_dep']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['Dependence']); ?></td>
                <td data-format="0" class="text-center"><?php echo e(" ".$item['validity']); ?></td>
                <td data-format="0" class="text-right"><?php echo e($item['cod_indicator']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['name_indicator']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['month']); ?></td>
                <td data-format="0" class="text-right"><?php echo e($item['goal']); ?></td>
                <td data-format="0.00" class="text-right"><?php echo e($item['execution_goals']); ?></td>
                <td data-format="0.00" class="text-right"><?php echo e($item['per']); ?></td>
                <td data-format="0.00" class="text-center"><?php echo e($item['expected_goal']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['justify_estate_indicator']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['justify_estate_money']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['observation_control']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['name_perspective']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['objective_strategy']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['name_strategy']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['start_date']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['end_date']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['physical_recursion']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['technical_recursion']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['human_resource']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['responsible_indicator']); ?></td>
                <td data-format="text" class="text-center"><?php echo e($item['post_responsible_indicator']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['assesor']); ?></td>
                <td data-format="text" class="text-left"><?php echo e($item['area']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div style="font-family: arial; width: 100%">
    <h2>Indicadores Presupuestales</h2>
    <table>
        <thead style="background-color: #9b9b9b; color:white;">
        <tr>
            <th>Código Regional</th>
            <th>Dependencia Control / Regional</th>
            <th>Código Dependencia</th>
            <th>Dependencia</th>
            <th>Vigencia</th>
            <th>Código SIIF</th>
            <th>Código de Proyecto</th>
            <th>Proyecto</th>
            <th>Apertura Presupuestal</th>
            <th>Comprometido</th>
            <th>Pago</th>
            <th>Porcentaje Comprometido</th>
            <th>Ejecución</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $money; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($m['cod_reg']); ?></td>
                <td><?php echo e($m['cod_control']); ?></td>
                <td><?php echo e($m['cod_dep']); ?></td>
                <td><?php echo e($m['dependence']); ?></td>
                <td><?php echo e($m['validity']); ?></td>
                <td><?php echo e($m['siif']); ?></td>
                <td><?php echo e($m['project_id']); ?></td>
                <td><?php echo e($m['project']); ?></td>
                <td><?php echo e('$ ' .number_format($m['open_money'])); ?></td>
                <td><?php echo e('$ ' . number_format($m['commitment'])); ?></td>
                <td><?php echo e('$ ' . number_format($m['payments'])); ?></td>
                <td><?php echo e(number_format(($m['commitment_percentage'])*100, 2)); ?>%</td>
                <td><?php echo e(number_format(($m['payment_execution'])*100, 2)); ?>%</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div><?php echo e(date('Y-m-d H:m:s')); ?></div>
</body>
</html>
<?php /**PATH /Users/wilson/PhpstormProjects/plannerapp/resources/views/Export/follow-close-export-two.blade.php ENDPATH**/ ?>